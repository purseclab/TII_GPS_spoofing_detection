*Details of Files

- '*.ubx': Recorded GPS messages while conducting GPS spoofing attacks and under normal situation
---> Please download 'u-center' software to check the recorded GPS messages
---> https://www.u-blox.com/en/product/u-center

- 'TII_Project_May_24_2022_Progress_Meeting.pptx': Slides explaining GPS spoofing detection

